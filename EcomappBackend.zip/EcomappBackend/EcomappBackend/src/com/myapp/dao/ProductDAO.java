package com.myapp.dao;

import com.myapp.model.Product;

public interface ProductDAO {

	boolean addProduct(Product product);
	boolean deleteProduct(int productId);
	
}

create table userinfo
(
employeeid number(6) primary key,
employeename varchar2(30) not null,
email varchar2(30) unique not null,
emppassword varchar2(30) ,
role_type varchar2(30),
deptname varchar2(30)
)

INSERT INTO userinfo (
   employeeid,
    employeename,
    email,
    emppassword,
    role_type,
    deptname
) VALUES (
    101,
    'kevin',
    'kevin@gmail.com',
    'pass1234',
    'role',
    'dept')
    
INSERT INTO userinfo (
   employeeid,
    employeename,
    email,
    emppassword,
    role_type,
    deptname
) VALUES (
    102,
    'paul',
    'paul@gmail.com',
    'pass1234',
    'role',
    'dept')
    
    
create table product
(
productid number(10) primary key,
prodname varchar2(30),
prodprice float(10)
);

drop table product;

insert into product values(201, 'Smart TV', 33000);
insert into product values(202, 'Aircondition', 27000);
insert into product values(203, 'Refrigerator', 18000);
insert into product values(204, 'Washing Machine', 9000);

select * from product;